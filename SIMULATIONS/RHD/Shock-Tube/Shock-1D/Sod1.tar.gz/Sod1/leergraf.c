#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	FILE *fdata;
	FILE *fexacta;
	int mesh;
	int num;
	int i;
	char data[10];
	char exacta[10];

	printf("Introduce el numero de puntos:\n");
	scanf("%d",&mesh);
	printf("Introduce el nombre del archivo de datos numericos:\n");
	scanf("%s",&data);
	printf("Introduce el nombre del archivo de datos exactos:\n");
	scanf("%s",&exacta);
	printf("Tiempo: \n");
	scanf("%d",&num);

	float Xd[mesh+1];
	float Nd[mesh+1];
	float Vd[mesh+1];
	float Pd[mesh+1];

	float Xe[mesh+1];
	float Ne[mesh+1];
	float Ve[mesh+1];
	float Pe[mesh+1];
	float Ee[mesh+1];

	fdata = fopen(data,"r");
	fexacta = fopen(exacta,"r");

	for(i=0; i<=mesh; i++)
	{
		fscanf(fdata,"%f %f %f %f",&Xd[i],&Nd[i],&Vd[i],&Pd[i]);
		fscanf(fexacta,"%f %f %f %f %f",&Xe[i],&Pe[i],&Ne[i],&Ve[i],&Ee[i]);
	}

	fclose(fdata);
	fclose(fexacta);

	float Dif[mesh+1];
	float L[mesh+1];
	FILE *file;
	char dat[4];
	char archivo[9];
	snprintf(dat,4,"%d",num);
	strcpy(archivo, "Ldata");
	strcat(archivo, dat);
	file = fopen(archivo, "w");

	for(i=0; i<=mesh; i++)
	{
		L[i] = fabs(Nd[i] - Ne[i])/Nd[i];
		fprintf(file, "%f %f\n", Xd[i], L[i]);
	}

	fclose(file);
	return 0;
}
